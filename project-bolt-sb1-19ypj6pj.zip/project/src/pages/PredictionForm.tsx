import React, { useState } from 'react';
import { AlertCircle, ArrowRight } from 'lucide-react';

const PredictionForm = () => {
  const [formData, setFormData] = useState({
    age: '',
    totalPurchase: '',
    accountManager: 'no',
    years: '',
    numSites: '',
  });
  
  const [prediction, setPrediction] = useState<null | {
    churnProbability: number;
    isHighRisk: boolean;
    factors: string[];
  }>(null);
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate prediction calculation
    setTimeout(() => {
      // In a real app, this would be a call to a machine learning model
      const age = parseFloat(formData.age);
      const totalPurchase = parseFloat(formData.totalPurchase);
      const hasAccountManager = formData.accountManager === 'yes';
      const years = parseFloat(formData.years);
      const numSites = parseFloat(formData.numSites);
      
      // Simple mock algorithm for demo purposes
      let churnScore = 0;
      
      // Age factor (younger customers tend to churn more)
      if (age < 35) churnScore += 0.2;
      
      // Purchase amount (lower purchases suggest higher churn)
      if (totalPurchase < 10000) churnScore += 0.25;
      
      // Account manager reduces churn
      if (!hasAccountManager) churnScore += 0.3;
      
      // Tenure (shorter relationships have higher churn)
      if (years < 5) churnScore += 0.15;
      
      // Number of sites (fewer sites suggests higher churn)
      if (numSites < 10) churnScore += 0.1;
      
      // Calculate final probability (ensure it's between 0 and 1)
      const probability = Math.min(0.95, Math.max(0.05, churnScore));
      
      // Determine risk factors
      const factors = [];
      if (age < 35) factors.push("Customer age below 35");
      if (totalPurchase < 10000) factors.push("Lower purchase amount");
      if (!hasAccountManager) factors.push("No account manager");
      if (years < 5) factors.push("Shorter customer relationship");
      if (numSites < 10) factors.push("Fewer engagement points");
      
      setPrediction({
        churnProbability: Math.round(probability * 100),
        isHighRisk: probability > 0.5,
        factors
      });
      
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-xl font-semibold mb-6 text-gray-800 dark:text-white">
        Customer Churn Prediction
      </h2>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="p-6">
          <h3 className="text-lg font-medium mb-4 text-gray-800 dark:text-white">
            Enter Customer Information
          </h3>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="age" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Customer Age
                </label>
                <input
                  type="number"
                  id="age"
                  name="age"
                  value={formData.age}
                  onChange={handleInputChange}
                  required
                  min="18"
                  max="100"
                  placeholder="Enter age"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              
              <div>
                <label htmlFor="totalPurchase" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Total Purchase Amount ($)
                </label>
                <input
                  type="number"
                  id="totalPurchase"
                  name="totalPurchase"
                  value={formData.totalPurchase}
                  onChange={handleInputChange}
                  required
                  min="0"
                  step="0.01"
                  placeholder="Enter total purchase"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              
              <div>
                <label htmlFor="accountManager" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Has Account Manager
                </label>
                <select
                  id="accountManager"
                  name="accountManager"
                  value={formData.accountManager}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="years" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Years as Customer
                </label>
                <input
                  type="number"
                  id="years"
                  name="years"
                  value={formData.years}
                  onChange={handleInputChange}
                  required
                  min="0"
                  step="0.1"
                  placeholder="Enter years"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
              
              <div>
                <label htmlFor="numSites" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Number of Sites
                </label>
                <input
                  type="number"
                  id="numSites"
                  name="numSites"
                  value={formData.numSites}
                  onChange={handleInputChange}
                  required
                  min="1"
                  placeholder="Enter number of sites"
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                />
              </div>
            </div>
            
            <div className="pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className={`w-full md:w-auto px-6 py-3 bg-indigo-600 text-white rounded-md font-medium ${
                  isSubmitting 
                    ? 'opacity-70 cursor-not-allowed' 
                    : 'hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
                } transition-colors duration-200 flex items-center justify-center`}
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    Predict Churn
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
        
        {prediction && (
          <div className={`p-6 border-t ${
            prediction.isHighRisk
              ? 'bg-red-50 dark:bg-red-900/20 border-red-100 dark:border-red-800'
              : 'bg-green-50 dark:bg-green-900/20 border-green-100 dark:border-green-800'
          }`}>
            <h3 className="text-lg font-medium mb-4 text-gray-800 dark:text-white">
              Prediction Results
            </h3>
            
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Churn Probability
                </p>
                <p className={`text-3xl font-bold ${
                  prediction.isHighRisk
                    ? 'text-red-600 dark:text-red-400'
                    : 'text-green-600 dark:text-green-400'
                }`}>
                  {prediction.churnProbability}%
                </p>
              </div>
              
              <div className={`mt-4 md:mt-0 px-4 py-2 rounded-full ${
                prediction.isHighRisk
                  ? 'bg-red-100 dark:bg-red-800/30 text-red-800 dark:text-red-200'
                  : 'bg-green-100 dark:bg-green-800/30 text-green-800 dark:text-green-200'
              }`}>
                {prediction.isHighRisk ? 'High Risk of Churn' : 'Low Risk of Churn'}
              </div>
            </div>
            
            {prediction.factors.length > 0 && (
              <div>
                <h4 className="text-md font-medium mb-2 flex items-center text-gray-800 dark:text-white">
                  <AlertCircle size={18} className="mr-2" />
                  Risk Factors
                </h4>
                <ul className="pl-6 list-disc space-y-1">
                  {prediction.factors.map((factor, index) => (
                    <li key={index} className="text-sm text-gray-600 dark:text-gray-300">
                      {factor}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="mt-6 text-sm text-gray-600 dark:text-gray-400">
              <p>
                This prediction is based on historical data patterns. Consider reaching out to this customer with a retention offer.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PredictionForm;