import React, { useContext, useState, useEffect } from 'react';
import { DataContext } from '../context/DataContext';
import { PieChart, BarChart, LineChart, TrendingUp, TrendingDown, Users, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';
import ChurnDistributionChart from '../components/charts/ChurnDistributionChart';
import CustomerMetricsChart from '../components/charts/CustomerMetricsChart';

const Dashboard = () => {
  const { data, isDataLoaded } = useContext(DataContext);
  const [metrics, setMetrics] = useState({
    totalCustomers: 0,
    churnRate: 0,
    avgPurchase: 0,
    avgAge: 0,
  });

  useEffect(() => {
    if (isDataLoaded && data.length > 0) {
      // Calculate metrics
      const totalCustomers = data.length;
      const churnedCustomers = data.filter(customer => customer.Churn === 'Yes' || customer.Churn === 1).length;
      const churnRate = (churnedCustomers / totalCustomers) * 100;
      
      // Calculate average purchase amount
      const totalPurchase = data.reduce((sum, customer) => {
        const purchase = typeof customer.Total_Purchase === 'string' 
          ? parseFloat(customer.Total_Purchase.replace(/,/g, '')) 
          : customer.Total_Purchase;
        return sum + (isNaN(purchase) ? 0 : purchase);
      }, 0);
      
      // Calculate average age
      const totalAge = data.reduce((sum, customer) => {
        const age = typeof customer.Age === 'string' 
          ? parseInt(customer.Age) 
          : customer.Age;
        return sum + (isNaN(age) ? 0 : age);
      }, 0);
      
      setMetrics({
        totalCustomers,
        churnRate: parseFloat(churnRate.toFixed(2)),
        avgPurchase: parseFloat((totalPurchase / totalCustomers).toFixed(2)),
        avgAge: parseFloat((totalAge / totalCustomers).toFixed(2)),
      });
    }
  }, [data, isDataLoaded]);

  // If no data is loaded yet, show placeholder or upload prompt
  if (!isDataLoaded) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="text-center max-w-md mx-auto p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">
            Welcome to Customer Churn Predictor
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Upload a customer dataset to get started with churn analysis and prediction.
          </p>
          <Link
            to="/data"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Upload Data
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Metric Cards */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Customers</p>
              <p className="text-2xl font-semibold text-gray-800 dark:text-white">{metrics.totalCustomers}</p>
            </div>
            <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900">
              <Users className="h-6 w-6 text-blue-600 dark:text-blue-300" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Churn Rate</p>
              <p className="text-2xl font-semibold text-gray-800 dark:text-white">{metrics.churnRate}%</p>
            </div>
            <div className="p-3 rounded-full bg-red-100 dark:bg-red-900">
              {metrics.churnRate > 15 ? (
                <TrendingUp className="h-6 w-6 text-red-600 dark:text-red-300" />
              ) : (
                <TrendingDown className="h-6 w-6 text-green-600 dark:text-green-300" />
              )}
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Purchase</p>
              <p className="text-2xl font-semibold text-gray-800 dark:text-white">${metrics.avgPurchase}</p>
            </div>
            <div className="p-3 rounded-full bg-green-100 dark:bg-green-900">
              <DollarSign className="h-6 w-6 text-green-600 dark:text-green-300" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 transform hover:scale-105">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Age</p>
              <p className="text-2xl font-semibold text-gray-800 dark:text-white">{metrics.avgAge}</p>
            </div>
            <div className="p-3 rounded-full bg-purple-100 dark:bg-purple-900">
              <Users className="h-6 w-6 text-purple-600 dark:text-purple-300" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Churn Distribution</h3>
          <div className="h-80">
            <ChurnDistributionChart />
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Customer Metrics</h3>
          <div className="h-80">
            <CustomerMetricsChart />
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link to="/data" className="flex items-center justify-center p-4 bg-indigo-50 dark:bg-indigo-900 rounded-md text-indigo-700 dark:text-indigo-200 hover:bg-indigo-100 dark:hover:bg-indigo-800 transition-colors duration-200">
            <Database className="h-5 w-5 mr-2" />
            <span>Explore Data</span>
          </Link>
          
          <Link to="/predict" className="flex items-center justify-center p-4 bg-purple-50 dark:bg-purple-900 rounded-md text-purple-700 dark:text-purple-200 hover:bg-purple-100 dark:hover:bg-purple-800 transition-colors duration-200">
            <Users className="h-5 w-5 mr-2" />
            <span>Predict Churn</span>
          </Link>
          
          <button className="flex items-center justify-center p-4 bg-teal-50 dark:bg-teal-900 rounded-md text-teal-700 dark:text-teal-200 hover:bg-teal-100 dark:hover:bg-teal-800 transition-colors duration-200">
            <BarChart className="h-5 w-5 mr-2" />
            <span>Generate Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;