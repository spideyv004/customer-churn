import React, { createContext, useState } from 'react';

interface DataContextType {
  data: any[];
  setData: React.Dispatch<React.SetStateAction<any[]>>;
  isDataLoaded: boolean;
  handleFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export const DataContext = createContext<DataContextType>({
  data: [],
  setData: () => {},
  isDataLoaded: false,
  handleFileUpload: () => {},
});

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<any[]>([]);
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  // Parse CSV file
  const parseCSV = (text: string) => {
    const lines = text.split('\n');
    const headers = lines[0].split(',').map(header => header.trim());
    
    const results = [];
    
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      // Handle quoted values with commas inside
      const values = [];
      let currentValue = '';
      let inQuotes = false;
      
      for (let j = 0; j < line.length; j++) {
        const char = line[j];
        
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          values.push(currentValue);
          currentValue = '';
        } else {
          currentValue += char;
        }
      }
      
      values.push(currentValue); // Add the last value
      
      if (values.length === headers.length) {
        const row: Record<string, any> = {};
        
        for (let j = 0; j < headers.length; j++) {
          // Remove quotes around the value
          let value = values[j].trim();
          if (value.startsWith('"') && value.endsWith('"')) {
            value = value.substr(1, value.length - 2);
          }
          
          // Try to convert to number if possible
          if (!isNaN(Number(value)) && value !== '') {
            row[headers[j]] = Number(value);
          } else {
            row[headers[j]] = value;
          }
        }
        
        results.push(row);
      }
    }
    
    return results;
  };

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (text) {
        try {
          const parsedData = parseCSV(text);
          setData(parsedData);
          setIsDataLoaded(true);
          
          // For development/demo, create sample data if none provided
          if (parsedData.length === 0) {
            generateSampleData();
          }
        } catch (error) {
          console.error("Error parsing CSV:", error);
          alert("Error parsing the CSV file. Please check the format.");
        }
      }
    };
    
    reader.readAsText(file);
  };

  // Generate sample data for demonstration if needed
  const generateSampleData = () => {
    const sampleData = [
      {
        Names: "Cameron Williams",
        Age: 42,
        Total_Purchase: 11066.8,
        Account_Manager: 0,
        Years: 7.22,
        Num_Sites: 8,
        Onboard_date: "30-08-2013 07:00",
        Location: "10265 Elizabeth Mission, Barkerburgh, AK 89518",
        Company: "Harvey LLC",
        Churn: "Yes"
      },
      {
        Names: "Kevin Mueller",
        Age: 41,
        Total_Purchase: 11916.22,
        Account_Manager: 0,
        Years: 6.5,
        Num_Sites: 11,
        Onboard_date: "13-08-2013 00:38",
        Location: "6157 Frank Gardens Suite 019, Carloshaven, RI 87323",
        Company: "Wilson PLC",
        Churn: "No"
      },
      {
        Names: "Eric Lozano",
        Age: 38,
        Total_Purchase: 12884.75,
        Account_Manager: 0,
        Years: 6.67,
        Num_Sites: 12,
        Onboard_date: "29-06-2016 06:20",
        Location: "1331 Keith Court, Alyssahaven, DE 90114",
        Company: "Miller, Johnson and Wallace",
        Churn: "Yes"
      },
      {
        Names: "Phillip White",
        Age: 42,
        Total_Purchase: 8010.76,
        Account_Manager: 0,
        Years: 6.71,
        Num_Sites: 10,
        Onboard_date: "22-04-2014 12:43",
        Location: "13120 Daniel Mount, Angelabury, WY 30645",
        Company: "Smith Inc",
        Churn: "No"
      },
      {
        Names: "Cynthia Norton",
        Age: 37,
        Total_Purchase: 9191.58,
        Account_Manager: 0,
        Years: 5.56,
        Num_Sites: 9,
        Onboard_date: "19-01-2016 15:31",
        Location: "765 Tricia Row, Karenshire, MH 71730",
        Company: "Love-Jones",
        Churn: "No"
      }
    ];
    
    setData(sampleData);
    setIsDataLoaded(true);
  };

  return (
    <DataContext.Provider value={{ data, setData, isDataLoaded, handleFileUpload }}>
      {children}
    </DataContext.Provider>
  );
};