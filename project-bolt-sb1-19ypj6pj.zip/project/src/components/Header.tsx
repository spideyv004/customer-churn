import React, { useContext } from 'react';
import { Moon, Sun, Upload } from 'lucide-react';
import { ThemeContext } from '../context/ThemeContext';
import { DataContext } from '../context/DataContext';

const Header = () => {
  const { darkMode, toggleTheme } = useContext(ThemeContext);
  const { handleFileUpload } = useContext(DataContext);
  
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm z-10 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">
            Customer Churn Predictor
          </h1>
          
          <div className="flex items-center space-x-4">
            <button
              onClick={triggerFileInput}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
            >
              <Upload size={16} className="mr-2" />
              Upload Data
            </button>
            <input
              type="file"
              ref={fileInputRef}
              accept=".csv"
              className="hidden"
              onChange={handleFileUpload}
            />
            
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
              aria-label="Toggle theme"
            >
              {darkMode ? (
                <Sun size={20} className="text-yellow-400" />
              ) : (
                <Moon size={20} className="text-indigo-600" />
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;