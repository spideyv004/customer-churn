import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { BarChart, Database, Users, Home, Menu, X } from 'lucide-react';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const navItems = [
    { name: 'Dashboard', path: '/', icon: <Home size={20} /> },
    { name: 'Data Exploration', path: '/data', icon: <Database size={20} /> },
    { name: 'Prediction', path: '/predict', icon: <Users size={20} /> },
  ];

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={toggleSidebar}
        className="md:hidden fixed z-20 top-4 left-4 p-2 rounded-md bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200"
      >
        <Menu size={24} />
      </button>

      {/* Overlay */}
      {isOpen && (
        <div
          className="md:hidden fixed inset-0 z-20 bg-black bg-opacity-50 transition-opacity"
          onClick={toggleSidebar}
        ></div>
      )}

      {/* Sidebar */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-30 w-64 bg-indigo-700 dark:bg-gray-800 text-white transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        } transition-transform duration-300 ease-in-out md:translate-x-0`}
      >
        <div className="flex items-center justify-between h-16 px-6 border-b border-indigo-800 dark:border-gray-700">
          <div className="flex items-center">
            <BarChart className="h-6 w-6 mr-2" />
            <span className="text-lg font-semibold">ChurnPredictor</span>
          </div>
          <button
            onClick={toggleSidebar}
            className="md:hidden text-white"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="mt-6 px-4">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center px-4 py-3 rounded-md transition-colors duration-200 ${
                      isActive
                        ? 'bg-indigo-800 dark:bg-gray-700'
                        : 'hover:bg-indigo-600 dark:hover:bg-gray-700'
                    }`
                  }
                  onClick={() => setIsOpen(false)}
                >
                  {item.icon}
                  <span className="ml-3">{item.name}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;