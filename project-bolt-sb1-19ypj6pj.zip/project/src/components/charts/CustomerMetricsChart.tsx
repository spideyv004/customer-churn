import React, { useContext, useEffect, useRef } from 'react';
import { DataContext } from '../../context/DataContext';
import { ThemeContext } from '../../context/ThemeContext';
import Chart from 'chart.js/auto';

const CustomerMetricsChart = () => {
  const { data, isDataLoaded } = useContext(DataContext);
  const { darkMode } = useContext(ThemeContext);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (!isDataLoaded || !chartRef.current) return;

    // Destroy existing chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    // Separate data by churn status
    const churnedCustomers = data.filter(customer => customer.Churn === 'Yes' || customer.Churn === 1);
    const retainedCustomers = data.filter(customer => customer.Churn === 'No' || customer.Churn === 0);

    // Calculate averages for each group
    const calculateAverage = (customers: any[], field: string) => {
      if (customers.length === 0) return 0;
      const sum = customers.reduce((acc, customer) => {
        const value = typeof customer[field] === 'string' 
          ? parseFloat(customer[field].replace(/,/g, '')) 
          : customer[field];
        return acc + (isNaN(value) ? 0 : value);
      }, 0);
      return sum / customers.length;
    };

    const metrics = [
      { label: 'Avg. Age', field: 'Age' },
      { label: 'Avg. Purchase ($)', field: 'Total_Purchase' },
      { label: 'Avg. Years as Customer', field: 'Years' },
      { label: 'Avg. Number of Sites', field: 'Num_Sites' }
    ];

    const churnedData = metrics.map(metric => calculateAverage(churnedCustomers, metric.field));
    const retainedData = metrics.map(metric => calculateAverage(retainedCustomers, metric.field));

    // Normalize the data to make it more comparable on the same scale
    const maxValues = metrics.map((metric, index) => 
      Math.max(churnedData[index], retainedData[index])
    );
    
    const normalizedChurnedData = churnedData.map((value, index) => 
      maxValues[index] ? (value / maxValues[index]) * 100 : 0
    );
    
    const normalizedRetainedData = retainedData.map((value, index) => 
      maxValues[index] ? (value / maxValues[index]) * 100 : 0
    );

    // Set chart colors based on theme
    const textColor = darkMode ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.8)';
    const gridColor = darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';

    // Create the chart
    const ctx = chartRef.current.getContext('2d');
    if (ctx) {
      chartInstance.current = new Chart(ctx, {
        type: 'radar',
        data: {
          labels: metrics.map(metric => metric.label),
          datasets: [
            {
              label: 'Churned Customers',
              data: normalizedChurnedData,
              backgroundColor: 'rgba(239, 68, 68, 0.2)',
              borderColor: 'rgba(239, 68, 68, 0.8)',
              pointBackgroundColor: 'rgba(239, 68, 68, 1)',
              pointBorderColor: '#fff',
              pointHoverBackgroundColor: '#fff',
              pointHoverBorderColor: 'rgba(239, 68, 68, 1)',
            },
            {
              label: 'Retained Customers',
              data: normalizedRetainedData,
              backgroundColor: 'rgba(34, 197, 94, 0.2)',
              borderColor: 'rgba(34, 197, 94, 0.8)',
              pointBackgroundColor: 'rgba(34, 197, 94, 1)',
              pointBorderColor: '#fff',
              pointHoverBackgroundColor: '#fff',
              pointHoverBorderColor: 'rgba(34, 197, 94, 1)',
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            r: {
              grid: {
                color: gridColor,
              },
              angleLines: {
                color: gridColor,
              },
              pointLabels: {
                color: textColor,
                font: {
                  size: 12,
                },
              },
              ticks: {
                display: false,
                backdropColor: 'transparent',
              },
            },
          },
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: textColor,
                padding: 20,
                font: {
                  size: 14,
                },
              },
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const datasetIndex = context.datasetIndex;
                  const index = context.dataIndex;
                  const originalValue = datasetIndex === 0 
                    ? churnedData[index] 
                    : retainedData[index];
                  
                  return `${context.dataset.label}: ${originalValue.toFixed(2)}`;
                }
              }
            }
          },
          animation: {
            duration: 2000,
            easing: 'easeOutQuart',
          },
        },
      });
    }

    // Cleanup on unmount
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, isDataLoaded, darkMode]);

  if (!isDataLoaded) {
    return <div className="h-full flex items-center justify-center">No data available</div>;
  }

  return <canvas ref={chartRef} />;
};

export default CustomerMetricsChart;