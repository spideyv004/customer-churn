import React, { useContext, useEffect, useRef } from 'react';
import { DataContext } from '../../context/DataContext';
import { ThemeContext } from '../../context/ThemeContext';
import Chart from 'chart.js/auto';

const ChurnDistributionChart = () => {
  const { data, isDataLoaded } = useContext(DataContext);
  const { darkMode } = useContext(ThemeContext);
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (!isDataLoaded || !chartRef.current) return;

    // Destroy existing chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    // Calculate churn distribution
    let churnedCount = 0;
    let retainedCount = 0;

    data.forEach(customer => {
      if (customer.Churn === 'Yes' || customer.Churn === 1) {
        churnedCount++;
      } else {
        retainedCount++;
      }
    });

    // Set chart colors based on theme
    const textColor = darkMode ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.8)';
    const gridColor = darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';

    // Create the chart
    const ctx = chartRef.current.getContext('2d');
    if (ctx) {
      chartInstance.current = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['Retained Customers', 'Churned Customers'],
          datasets: [
            {
              data: [retainedCount, churnedCount],
              backgroundColor: [
                'rgba(34, 197, 94, 0.8)',  // Green for retained
                'rgba(239, 68, 68, 0.8)',  // Red for churned
              ],
              borderColor: [
                'rgba(34, 197, 94, 1)',
                'rgba(239, 68, 68, 1)',
              ],
              borderWidth: 1,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: textColor,
                padding: 20,
                font: {
                  size: 14,
                },
              },
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const label = context.label || '';
                  const value = context.raw as number;
                  const total = churnedCount + retainedCount;
                  const percentage = Math.round((value / total) * 100);
                  return `${label}: ${value} (${percentage}%)`;
                }
              }
            }
          },
          cutout: '60%',
          animation: {
            animateScale: true,
            animateRotate: true,
            duration: 2000,
            easing: 'easeOutQuart',
          },
        },
      });
    }

    // Cleanup on unmount
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, isDataLoaded, darkMode]);

  if (!isDataLoaded) {
    return <div className="h-full flex items-center justify-center">No data available</div>;
  }

  return <canvas ref={chartRef} />;
};

export default ChurnDistributionChart;